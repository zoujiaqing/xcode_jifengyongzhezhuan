//
//  ViewController.m
//  TaomeeFeedbackTest
//
//  Created by Michael Wong on 5/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import "TaomeeFeedback.h"
#import "TFPostMessageViewController.h"
#import "TFAnswerViewController.h"
#import "TFFAQViewController.h"
#import "TFForumViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize userIdField;
@synthesize versionLabel;
@synthesize forumIdField;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    userIdField.text = @"8028582";
    forumIdField.text = @"1";
    NSString *currentApplicationVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString*)kCFBundleVersionKey];
    versionLabel.text = currentApplicationVersion;
    
    /*
    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    NSArray *array = [storage cookiesForURL:[NSURL URLWithString:@"http://wlad.61.com/bbs"]];
    for (id obj in array) {
        [storage deleteCookie:obj];
    }
    */
    
    TaomeeFeedback *feedback = [TaomeeFeedback shared];
    UIApplication *app = [UIApplication sharedApplication];
    AppDelegate *delegate = [app delegate];
    feedback.userId = [self.userIdField.text intValue];
    feedback.forumId = [self.forumIdField text];
    feedback.viewController = delegate.viewController;
    feedback.delegate = delegate.viewController;
    
    //[feedback fetchInformation];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotate
{
    return YES;
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscape;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIInterfaceOrientationIsLandscape(interfaceOrientation);
}

- (IBAction)openFeedbackUI:(id)sender {
    // to open feedback UI
    AppDelegate *_AppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    //[TaomeeFeedback showFeedbackWithUserId:[self.userIdField.text intValue] viewControll:_AppDelegate.viewController delegate:self];
    [TaomeeFeedback showFeedbackWithUserId:[self.userIdField.text intValue] password:nil forumId:[self.forumIdField text] viewControll:_AppDelegate.viewController delegate:nil];
}

- (void)onFeedbackViewClosed
{
    NSLog(@"onFeedbackViewClosed");
}

- (void)onFeedbackInformation
{
    NSLog(@"onFeedbackInformation:%@", [[TaomeeFeedback shared] information]);
}


- (IBAction)onButton1ClickDown:(UIButton *)button1
{
    
    TaomeeFeedback *feedback = [TaomeeFeedback shared];
    /*
    UIApplication *app = [UIApplication sharedApplication];
    AppDelegate *delegate = [app delegate];
    feedback.userId = [self.userIdField.text intValue];
    feedback.forumId = [self.forumIdField text];
    feedback.viewController = delegate.viewController;
    feedback.delegate = delegate.viewController;
    */
    [feedback showFeedbackWithModule:TaomeeFeedbackSubmitModule];
}

- (IBAction)onButton2ClickDown:(UIButton *)button2
{
    TaomeeFeedback *feedback = [TaomeeFeedback shared];
    /*
    UIApplication *app = [UIApplication sharedApplication];
    AppDelegate *delegate = [app delegate];
    feedback.userId = [self.userIdField.text intValue];
    feedback.forumId = [self.forumIdField text];
    feedback.viewController = delegate.viewController;
    feedback.delegate = delegate.viewController;
    */
    [feedback showFeedbackWithModule:TaomeeFeedbackAnswerModule];
}

- (IBAction)onButton3ClickDown:(UIButton *)button3
{
    TaomeeFeedback *feedback = [TaomeeFeedback shared];
    /*
    UIApplication *app = [UIApplication sharedApplication];
    AppDelegate *delegate = [app delegate];
    feedback.userId = [self.userIdField.text intValue];
    feedback.forumId = [self.forumIdField text];
    feedback.viewController = delegate.viewController;
    feedback.delegate = delegate.viewController;
    */
    [feedback showFeedbackWithModule:TaomeeFeedbackFAQModule];
}

- (IBAction)onButton4ClickDown:(UIButton *)button4
{
    TaomeeFeedback *feedback = [TaomeeFeedback shared];
    /*
    UIApplication *app = [UIApplication sharedApplication];
    AppDelegate *delegate = [app delegate];
    feedback.userId = [self.userIdField.text intValue];
    feedback.forumId = [self.forumIdField text];
    feedback.viewController = delegate.viewController;
    feedback.delegate = delegate.viewController;
    */
    [feedback showFeedbackWithModule:TaomeeFeedbackBBSModule];;
}

- (void)dealloc
{
    [userIdField release];
    [versionLabel release];
    [forumIdField release];
    [_button1 release];
    [_button2 release];
    [_button3 release];
    [_button4 release];
    [super dealloc];
}

@end
