//
//  ViewController.h
//  TaomeeFeedbackDemo
//
//  Created by Michael Wong on 5/10/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TaomeeFeedback.h"

@interface ViewController : UIViewController <TaomeeFeedbackDelegate>
{
    UITextField *userIdField;
    UILabel *versionLabel;
    UITextField *forumIdField;
}

@property(nonatomic, retain) IBOutlet UITextField *userIdField;
@property(nonatomic, retain) IBOutlet UILabel *versionLabel;
@property(nonatomic, retain) IBOutlet UITextField *forumIdField;

@property (nonatomic, retain) IBOutlet UIButton *button1;
@property (nonatomic, retain) IBOutlet UIButton *button2;
@property (nonatomic, retain) IBOutlet UIButton *button3;
@property (nonatomic, retain) IBOutlet UIButton *button4;

- (IBAction)openFeedbackUI:(id)sender ;

- (void)onFeedbackViewClosed;

@end
